from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F

class ConvVAE(nn.Module):
    def __init__(self, in_ch=3, latent_dim=256, base=64):
        super().__init__()
        self.enc = nn.Sequential(
            nn.Conv2d(in_ch, base, 4,2,1), nn.ReLU(True),
            nn.Conv2d(base, base*2, 4,2,1), nn.BatchNorm2d(base*2), nn.ReLU(True),
            nn.Conv2d(base*2, base*4, 4,2,1), nn.BatchNorm2d(base*4), nn.ReLU(True),
            nn.Conv2d(base*4, base*8, 4,2,1), nn.BatchNorm2d(base*8), nn.ReLU(True),
        )
        self.fc_mu = nn.Linear(base*8*16*16, latent_dim)
        self.fc_logvar = nn.Linear(base*8*16*16, latent_dim)
        self.fc = nn.Linear(latent_dim, base*8*16*16)
        self.dec = nn.Sequential(
            nn.ConvTranspose2d(base*8, base*4, 4,2,1), nn.BatchNorm2d(base*4), nn.ReLU(True),
            nn.ConvTranspose2d(base*4, base*2, 4,2,1), nn.BatchNorm2d(base*2), nn.ReLU(True),
            nn.ConvTranspose2d(base*2, base, 4,2,1), nn.BatchNorm2d(base), nn.ReLU(True),
            nn.ConvTranspose2d(base, in_ch, 4,2,1), nn.Tanh()
        )

    def encode(self, x):
        h = self.enc(x)
        h = h.view(h.size(0), -1)
        return self.fc_mu(h), self.fc_logvar(h)

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5*logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(self, z):
        h = self.fc(z).view(z.size(0), -1, 16, 16)
        return self.dec(h)

    def forward(self, x):
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        rec = self.decode(z)
        return rec, mu, logvar

def vae_loss(recon_x, x, mu, logvar):
    rec = F.l1_loss(recon_x, x)
    kld = -0.5 * torch.mean(1 + logvar - mu.pow(2) - logvar.exp())
    return rec + 1e-3*kld, {"recon": float(rec.detach().cpu()), "kld": float(kld.detach().cpu())}
