from __future__ import annotations
import torch
from torchmetrics.image.fid import FrechetInceptionDistance

class FID:
    def __init__(self, device="cpu", feature=2048):
        self.metric = FrechetInceptionDistance(feature=feature, normalize=True).to(device)

    @torch.no_grad()
    def update(self, preds: torch.Tensor, reals: torch.Tensor):
        # expects uint8 [0,255] or float [0,1] with normalize=True; we pass float [0,1]
        p = (preds + 1.0) / 2.0
        r = (reals + 1.0) / 2.0
        self.metric.update(r, real=True)
        self.metric.update(p, real=False)

    @torch.no_grad()
    def compute(self) -> float:
        return float(self.metric.compute().cpu())

    def reset(self):
        self.metric.reset()
