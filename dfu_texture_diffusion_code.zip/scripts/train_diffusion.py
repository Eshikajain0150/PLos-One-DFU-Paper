from __future__ import annotations
import argparse
from pathlib import Path
import math
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm

from src.utils.seed import seed_everything
from src.utils.io import ensure_dir, save_json
from src.data.dfu_dataset import DFUPairedPseudoProgression
from src.texture.encoder import TextureEncoder
from src.models.diffusion.schedule import DiffusionSchedule
from src.models.diffusion.unet_ca import UNetConditionalCA
from src.models.diffusion.ddpm import p_losses
from src.models.gan.discriminator import PatchDiscriminator
from src.train.ema import EMA
from src.train.losses import PerceptualLoss

def cosine_lr(step, total_steps, lr):
    return lr * 0.5 * (1 + math.cos(math.pi * step / total_steps))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_root", required=True)
    ap.add_argument("--splits_dir", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--epochs", type=int, default=300)
    ap.add_argument("--batch_size", type=int, default=8)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--weight_decay", type=float, default=1e-4)
    ap.add_argument("--timesteps", type=int, default=1000)
    ap.add_argument("--ema_decay", type=float, default=0.999)
    ap.add_argument("--num_workers", type=int, default=4)
    ap.add_argument("--use_texture", type=int, default=1)
    ap.add_argument("--use_cross_attention", type=int, default=1)
    ap.add_argument("--lambda_recon", type=float, default=1.0)
    ap.add_argument("--lambda_perc", type=float, default=0.1)
    ap.add_argument("--lambda_adv", type=float, default=0.05)
    ap.add_argument("--lambda_cons", type=float, default=0.05)
    args = ap.parse_args()

    seed_everything(args.seed)
    out_dir = Path(ensure_dir(args.out_dir))
    ckpt_dir = Path(ensure_dir(out_dir / "checkpoints"))
    ensure_dir(out_dir / "logs")
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # data
    ref_hist = str(Path(args.splits_dir) / "reference_hist.npy")
    train_ds = DFUPairedPseudoProgression(args.data_root, str(Path(args.splits_dir)/"train.csv"), ref_hist, augment=True, seed=args.seed)
    val_ds = DFUPairedPseudoProgression(args.data_root, str(Path(args.splits_dir)/"val.csv"), ref_hist, augment=False, seed=args.seed)
    train_ld = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=True, drop_last=True)
    val_ld = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True)

    # models
    model = UNetConditionalCA(use_cross_attention=bool(args.use_cross_attention)).to(device)
    tex = TextureEncoder(token_dim=256).to(device) if args.use_texture else None
    disc = PatchDiscriminator().to(device)

    schedule = DiffusionSchedule(args.timesteps, device=device)

    opt_g = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay, betas=(0.9,0.999))
    opt_d = torch.optim.AdamW(disc.parameters(), lr=args.lr, weight_decay=args.weight_decay, betas=(0.9,0.999))

    ema = EMA(model, decay=args.ema_decay)
    perc = PerceptualLoss().to(device)

    scaler = torch.cuda.amp.GradScaler(enabled=(device=="cuda"))
    global_step = 0
    total_steps = args.epochs * len(train_ld)

    def save_ckpt(name: str):
        torch.save({
            "model": model.state_dict(),
            "ema": ema.state_dict(),
            "disc": disc.state_dict(),
            "opt_g": opt_g.state_dict(),
            "opt_d": opt_d.state_dict(),
            "args": vars(args),
        }, ckpt_dir / name)

    model.train()
    disc.train()

    for epoch in range(1, args.epochs+1):
        pbar = tqdm(train_ld, desc=f"epoch {epoch}/{args.epochs}")
        for batch in pbar:
            x = batch["x"].to(device, non_blocking=True)  # condition
            y = batch["y"].to(device, non_blocking=True)  # target
            bsz = x.size(0)
            t = torch.randint(0, schedule.timesteps, (bsz,), device=device).long()

            tokens = tex(x) if tex is not None else None

            # --------- Generator (diffusion) loss ----------
            with torch.cuda.amp.autocast(enabled=(device=="cuda")):
                l_diff = p_losses(model, schedule, x, y, t, tokens, loss_type="l2")

                # reconstruct x0 estimate from one-step denoise for auxiliary losses
                # y_t = sqrt(ab)*y + sqrt(1-ab)*eps ; model predicts eps_hat -> x0_hat = (y_t - sqrt(1-ab)*eps_hat)/sqrt(ab)
                noise = torch.randn_like(y)
                y_t = schedule.sqrt_alphas_cumprod[t].view(-1,1,1,1) * y + schedule.sqrt_one_minus_alphas_cumprod[t].view(-1,1,1,1) * noise
                eps_hat = model(y_t, x, t, tokens)
                x0_hat = (y_t - schedule.sqrt_one_minus_alphas_cumprod[t].view(-1,1,1,1) * eps_hat) / (schedule.sqrt_alphas_cumprod[t].view(-1,1,1,1) + 1e-8)
                x0_hat = torch.clamp(x0_hat, -1, 1)

                l_recon = F.l1_loss(x0_hat, y)
                l_perc = perc(x0_hat, y)

                # feature-consistency proxy: keep VGG features of generated close to condition in early layers
                l_cons = perc(x0_hat, x)  # proxy; can be replaced with latent feature alignment

                # adversarial (PatchGAN) on (condition, generated) pairs
                logits_fake = disc(torch.cat([x, x0_hat], dim=1))
                l_adv_g = F.softplus(-logits_fake).mean()

                loss_g = l_diff + args.lambda_recon*l_recon + args.lambda_perc*l_perc + args.lambda_cons*l_cons + args.lambda_adv*l_adv_g

            opt_g.zero_grad(set_to_none=True)
            scaler.scale(loss_g).backward()
            scaler.step(opt_g)
            scaler.update()

            # --------- Discriminator loss ----------
            with torch.cuda.amp.autocast(enabled=(device=="cuda")):
                logits_real = disc(torch.cat([x, y], dim=1))
                logits_fake = disc(torch.cat([x, x0_hat.detach()], dim=1))
                l_d = (F.softplus(-logits_real).mean() + F.softplus(logits_fake).mean())

            opt_d.zero_grad(set_to_none=True)
            scaler.scale(l_d).backward()
            scaler.step(opt_d)

            # EMA + cosine LR
            ema.update(model)
            lr_now = cosine_lr(global_step, total_steps, args.lr)
            for pg in opt_g.param_groups:
                pg["lr"] = lr_now
            for pg in opt_d.param_groups:
                pg["lr"] = lr_now

            global_step += 1
            pbar.set_postfix({
                "loss_g": float(loss_g.detach().cpu()),
                "l_diff": float(l_diff.detach().cpu()),
                "l_recon": float(l_recon.detach().cpu()),
                "l_perc": float(l_perc.detach().cpu()),
                "l_adv_g": float(l_adv_g.detach().cpu()),
                "l_d": float(l_d.detach().cpu()),
                "lr": lr_now
            })

        # save checkpoint each epoch (journals often ask for reproducibility)
        save_ckpt(f"epoch_{epoch:03d}.pt")
        save_ckpt("last.pt")
        torch.save(ema.state_dict(), ckpt_dir / "ema_last.pt")

        # quick validation diffusion loss (EMA model not used here to keep it lightweight)
        model.eval()
        with torch.no_grad():
            vloss = 0.0
            n = 0
            for vb in val_ld:
                x = vb["x"].to(device)
                y = vb["y"].to(device)
                t = torch.randint(0, schedule.timesteps, (x.size(0),), device=device).long()
                tokens = tex(x) if tex is not None else None
                vloss += float(p_losses(model, schedule, x, y, t, tokens).detach().cpu()) * x.size(0)
                n += x.size(0)
        model.train()
        save_json({"epoch": epoch, "val_diffusion_loss": vloss/max(1,n)}, str(out_dir/"logs"/f"val_epoch_{epoch:03d}.json"))

    print("Training finished. Final EMA checkpoint:", ckpt_dir/"ema_last.pt")

if __name__ == "__main__":
    main()
