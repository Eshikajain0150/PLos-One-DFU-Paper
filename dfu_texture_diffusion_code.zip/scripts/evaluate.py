from __future__ import annotations
import argparse
from pathlib import Path
import json
import numpy as np
import cv2
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from src.utils.io import ensure_dir, save_json
from src.data.dfu_dataset import DFUPairedPseudoProgression
from src.texture.encoder import TextureEncoder
from src.models.diffusion.schedule import DiffusionSchedule
from src.models.diffusion.unet_ca import UNetConditionalCA
from src.models.diffusion.ddpm import sample
from src.models.gan.generator import UNetGenerator
from src.models.vae.vae import ConvVAE
from src.metrics.ssim_psnr import SSIM_PSNR
from src.metrics.fid import FID
from src.metrics.tcs import texture_consistency_score
from src.metrics.gtfs import gtfs

def tensor_to_rgb_uint8(x: torch.Tensor) -> np.ndarray:
    # x: (3,H,W) [-1,1]
    x = (x + 1.0) / 2.0
    x = torch.clamp(x, 0, 1).permute(1,2,0).cpu().numpy()
    return (x * 255.0).astype(np.uint8)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_root", required=True)
    ap.add_argument("--splits_dir", required=True)
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--model", choices=["diffusion","gan","vae"], required=True)
    ap.add_argument("--batch_size", type=int, default=8)
    ap.add_argument("--timesteps", type=int, default=1000)
    ap.add_argument("--num_workers", type=int, default=4)
    ap.add_argument("--granulation_masks_dir", default=None)
    ap.add_argument("--use_texture", type=int, default=1)
    ap.add_argument("--use_cross_attention", type=int, default=1)
    args = ap.parse_args()

    out_dir = Path(ensure_dir(args.out_dir))
    device = "cuda" if torch.cuda.is_available() else "cpu"

    ref_hist = str(Path(args.splits_dir) / "reference_hist.npy")
    test_ds = DFUPairedPseudoProgression(args.data_root, str(Path(args.splits_dir)/"test.csv"), ref_hist, augment=False, seed=2026)
    test_ld = DataLoader(test_ds, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True)

    ssim_psnr = SSIM_PSNR(device=device)
    fid = FID(device=device)

    if args.model == "diffusion":
        schedule = DiffusionSchedule(args.timesteps, device=device)
        model = UNetConditionalCA(use_cross_attention=bool(args.use_cross_attention)).to(device)
        tex = TextureEncoder(token_dim=256).to(device) if args.use_texture else None

        ck = torch.load(args.ckpt, map_location=device)
        # allow loading EMA-only checkpoints
        if "ema" in ck:
            model.load_state_dict(ck["ema"], strict=False)
        elif "model" in ck:
            model.load_state_dict(ck["model"], strict=False)
        else:
            model.load_state_dict(ck, strict=False)
        model.eval()

    elif args.model == "gan":
        G = UNetGenerator().to(device)
        ck = torch.load(args.ckpt, map_location=device)
        G.load_state_dict(ck["G"])
        G.eval()

    else:  # vae
        V = ConvVAE().to(device)
        ck = torch.load(args.ckpt, map_location=device)
        V.load_state_dict(ck["V"])
        V.eval()

    ssim_list, psnr_list, tcs_list, gtfs_list = [], [], [], []

    with torch.no_grad():
        for i, b in enumerate(tqdm(test_ld, desc="Evaluating")):
            x = b["x"].to(device)
            y = b["y"].to(device)
            paths = b["y_path"]

            if args.model == "diffusion":
                tokens = tex(x) if (args.use_texture and tex is not None) else None
                pred = sample(model, schedule, x, tokens)  # predicted progressed image
            elif args.model == "gan":
                pred = G(x)
            else:
                pred, _, _ = V(x)  # recon baseline

            ssim_v, psnr_v = ssim_psnr(pred, y)
            ssim_list.append(ssim_v); psnr_list.append(psnr_v)

            # update FID in batch
            fid.update(pred, y)

            # compute TCS + GTFS per-image on CPU
            for k in range(pred.size(0)):
                pr = tensor_to_rgb_uint8(pred[k])
                yr = tensor_to_rgb_uint8(y[k])
                tcs_list.append(texture_consistency_score(pr, yr))
                gtfs_list.append(gtfs(pr, yr, paths[k], masks_dir=args.granulation_masks_dir))

            # save a few visual samples
            if i == 0:
                grid = []
                for k in range(min(8, pred.size(0))):
                    pr = tensor_to_rgb_uint8(pred[k])
                    yr = tensor_to_rgb_uint8(y[k])
                    xc = tensor_to_rgb_uint8(x[k])
                    row = np.concatenate([xc, pr, yr], axis=1)
                    grid.append(row)
                grid = np.concatenate(grid, axis=0)
                cv2.imwrite(str(out_dir/"samples_first_batch.png"), cv2.cvtColor(grid, cv2.COLOR_RGB2BGR))

    results = {
        "SSIM_mean": float(np.mean(ssim_list)), "SSIM_std": float(np.std(ssim_list)),
        "PSNR_mean": float(np.mean(psnr_list)), "PSNR_std": float(np.std(psnr_list)),
        "FID": float(fid.compute()),
        "TCS_mean": float(np.mean(tcs_list)), "TCS_std": float(np.std(tcs_list)),
        "GTFS_mean": float(np.mean(gtfs_list)), "GTFS_std": float(np.std(gtfs_list)),
        "n": int(len(test_ds)),
    }
    save_json(results, str(out_dir/"metrics.json"))
    print(json.dumps(results, indent=2))

if __name__ == "__main__":
    main()
