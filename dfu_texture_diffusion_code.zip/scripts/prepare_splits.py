from __future__ import annotations
import argparse
from pathlib import Path
import csv
import numpy as np
import cv2
from tqdm import tqdm

from src.utils.seed import seed_everything
from src.utils.io import ensure_dir
from src.data.discovery import discover_images
from src.data.severity import severity_score
from src.data.preprocess import resize_pad, build_reference_hist

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_root", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--num_stages", type=int, default=4)
    ap.add_argument("--image_size", type=int, default=256)
    ap.add_argument("--ref_subset", type=int, default=64, help="How many training images to build reference histogram.")
    args = ap.parse_args()

    seed_everything(args.seed)
    out_dir = Path(ensure_dir(args.out_dir))

    paths = discover_images(args.data_root)
    if len(paths) == 0:
        raise SystemExit("No images found under data_root. Check the path.")

    # convert to relative paths for portability
    root = Path(args.data_root)
    rel = [str(Path(p).relative_to(root)) for p in paths]

    # compute severity scores
    scores = []
    for p in tqdm(paths, desc="Scoring severity"):
        img = cv2.imread(p, cv2.IMREAD_COLOR)
        if img is None:
            scores.append(0.0); continue
        scores.append(severity_score(img))
    scores = np.asarray(scores, dtype=np.float32)

    # assign stages by quantiles (ordinal pseudo-stages)
    qs = [np.quantile(scores, q) for q in np.linspace(0, 1, args.num_stages+1)]
    stages = np.zeros_like(scores, dtype=np.int64)
    for s in range(args.num_stages):
        lo, hi = qs[s], qs[s+1]
        if s == args.num_stages-1:
            m = (scores >= lo) & (scores <= hi)
        else:
            m = (scores >= lo) & (scores < hi)
        stages[m] = s

    # fixed 70/15/15 split
    rng = np.random.default_rng(args.seed)
    idx = np.arange(len(rel))
    rng.shuffle(idx)
    n = len(idx)
    n_train = int(round(0.70 * n))
    n_val = int(round(0.15 * n))
    train_idx = idx[:n_train]
    val_idx = idx[n_train:n_train+n_val]
    test_idx = idx[n_train+n_val:]

    def write_csv(name, ids):
        with open(out_dir / f"{name}.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["path","stage","score"])
            for i in ids:
                w.writerow([rel[i], int(stages[i]), float(scores[i])])

    write_csv("train", train_idx)
    write_csv("val", val_idx)
    write_csv("test", test_idx)

    # build reference histogram from subset of training images (after resize/pad only)
    subset = train_idx[:min(args.ref_subset, len(train_idx))]
    ims = []
    for i in subset:
        img = cv2.imread(str(root / rel[i]), cv2.IMREAD_COLOR)
        if img is None: 
            continue
        img = resize_pad(img, args.image_size)
        ims.append(img)
    ref = build_reference_hist(ims)
    np.save(out_dir / "reference_hist.npy", ref)

    print("Wrote splits to:", out_dir)

if __name__ == "__main__":
    main()
