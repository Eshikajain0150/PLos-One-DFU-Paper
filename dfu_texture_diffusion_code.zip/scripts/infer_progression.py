from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import cv2
import torch

from src.utils.io import ensure_dir
from src.data.preprocess import resize_pad, background_suppress, multi_scale_texture_enhance, histogram_match
from src.texture.encoder import TextureEncoder
from src.models.diffusion.schedule import DiffusionSchedule
from src.models.diffusion.unet_ca import UNetConditionalCA
from src.models.diffusion.ddpm import sample

def tensor_to_rgb_uint8(x: torch.Tensor) -> np.ndarray:
    x = (x + 1.0) / 2.0
    x = torch.clamp(x, 0, 1).permute(1,2,0).cpu().numpy()
    return (x * 255.0).astype(np.uint8)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--image", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--reference_hist", default=None, help="Optional: reference_hist.npy for histogram matching.")
    ap.add_argument("--timesteps", type=int, default=1000)
    ap.add_argument("--use_texture", type=int, default=1)
    ap.add_argument("--use_cross_attention", type=int, default=1)
    args = ap.parse_args()

    out_dir = Path(ensure_dir(args.out_dir))
    device = "cuda" if torch.cuda.is_available() else "cpu"

    img = cv2.imread(args.image, cv2.IMREAD_COLOR)
    if img is None:
        raise SystemExit("Could not read input image.")
    img = resize_pad(img, 256)
    img = background_suppress(img)
    img = multi_scale_texture_enhance(img)
    if args.reference_hist is not None and Path(args.reference_hist).exists():
        ref_hist = np.load(args.reference_hist)
        img = histogram_match(img, ref_hist)

    rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    x = torch.from_numpy(rgb).permute(2,0,1).float() / 127.5 - 1.0
    x = x.unsqueeze(0).to(device)

    schedule = DiffusionSchedule(args.timesteps, device=device)
    model = UNetConditionalCA(use_cross_attention=bool(args.use_cross_attention)).to(device)
    tex = TextureEncoder(token_dim=256).to(device) if args.use_texture else None

    ck = torch.load(args.ckpt, map_location=device)
    if "ema" in ck:
        model.load_state_dict(ck["ema"], strict=False)
    elif "model" in ck:
        model.load_state_dict(ck["model"], strict=False)
    else:
        model.load_state_dict(ck, strict=False)
    model.eval()

    with torch.no_grad():
        tokens = tex(x) if (tex is not None and args.use_texture) else None
        y = sample(model, schedule, x, tokens)
    out_img = tensor_to_rgb_uint8(y[0])
    in_img = tensor_to_rgb_uint8(x[0])

    montage = np.concatenate([in_img, out_img], axis=1)
    cv2.imwrite(str(out_dir/"progression.png"), cv2.cvtColor(montage, cv2.COLOR_RGB2BGR))
    print("Wrote:", out_dir/"progression.png")

if __name__ == "__main__":
    main()
