from __future__ import annotations
import torch
from torchmetrics.image import StructuralSimilarityIndexMeasure
from torchmetrics.image import PeakSignalNoiseRatio

class SSIM_PSNR:
    def __init__(self, device="cpu"):
        self.ssim = StructuralSimilarityIndexMeasure(data_range=1.0).to(device)
        self.psnr = PeakSignalNoiseRatio(data_range=1.0).to(device)

    @torch.no_grad()
    def __call__(self, pred: torch.Tensor, target: torch.Tensor):
        # pred/target: [-1,1] -> [0,1]
        p = (pred + 1.0) / 2.0
        t = (target + 1.0) / 2.0
        return float(self.ssim(p, t).cpu()), float(self.psnr(p, t).cpu())
