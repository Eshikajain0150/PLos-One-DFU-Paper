from __future__ import annotations
import numpy as np
import cv2
from scipy.spatial.distance import cosine
from skimage.feature import local_binary_pattern

def _lbp_hist_from_rgb(img_rgb: np.ndarray, P=8, R=1) -> np.ndarray:
    gray = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2GRAY)
    lbp = local_binary_pattern(gray, P=P, R=R, method="uniform")
    lbp = lbp.astype(np.float32)
    lbp = lbp / (lbp.max() + 1e-6)
    h, _ = np.histogram(lbp.ravel(), bins=59, range=(0,1), density=True)
    return h.astype(np.float32)

def texture_consistency_score(pred_rgb: np.ndarray, ref_rgb: np.ndarray) -> float:
    """TCS: cosine similarity between LBP histograms (higher is better)."""
    h1 = _lbp_hist_from_rgb(pred_rgb)
    h2 = _lbp_hist_from_rgb(ref_rgb)
    return float(1.0 - cosine(h1, h2))
