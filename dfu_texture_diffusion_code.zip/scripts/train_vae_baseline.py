from __future__ import annotations
import argparse
from pathlib import Path
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from src.utils.seed import seed_everything
from src.utils.io import ensure_dir
from src.data.dfu_dataset import DFUPairedPseudoProgression
from src.models.vae.vae import ConvVAE, vae_loss

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_root", required=True)
    ap.add_argument("--splits_dir", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--epochs", type=int, default=200)
    ap.add_argument("--batch_size", type=int, default=8)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--num_workers", type=int, default=4)
    args = ap.parse_args()

    seed_everything(args.seed)
    out_dir = Path(ensure_dir(args.out_dir))
    ckpt_dir = Path(ensure_dir(out_dir / "checkpoints"))
    device = "cuda" if torch.cuda.is_available() else "cpu"

    ref_hist = str(Path(args.splits_dir) / "reference_hist.npy")
    train_ds = DFUPairedPseudoProgression(args.data_root, str(Path(args.splits_dir)/"train.csv"), ref_hist, augment=True, seed=args.seed)
    train_ld = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=True, drop_last=True)

    V = ConvVAE().to(device)
    opt = torch.optim.Adam(V.parameters(), lr=args.lr)

    for epoch in range(1, args.epochs+1):
        pbar = tqdm(train_ld, desc=f"VAE epoch {epoch}/{args.epochs}")
        for b in pbar:
            x = b["x"].to(device)
            # VAE baseline reconstructs input (not progression)
            rec, mu, logvar = V(x)
            loss, parts = vae_loss(rec, x, mu, logvar)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
            pbar.set_postfix({"loss": float(loss.detach().cpu()), **parts})

        torch.save({"V": V.state_dict(), "args": vars(args)}, ckpt_dir/f"epoch_{epoch:03d}.pt")
        torch.save({"V": V.state_dict(), "args": vars(args)}, ckpt_dir/"last.pt")

    print("VAE baseline done:", ckpt_dir/"last.pt")

if __name__ == "__main__":
    main()
