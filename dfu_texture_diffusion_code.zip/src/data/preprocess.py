from __future__ import annotations
import numpy as np
import cv2

def resize_pad(img: np.ndarray, size: int = 256) -> np.ndarray:
    h, w = img.shape[:2]
    scale = size / max(h, w)
    nh, nw = int(round(h * scale)), int(round(w * scale))
    img_r = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_AREA if scale < 1 else cv2.INTER_CUBIC)
    top = (size - nh) // 2
    bottom = size - nh - top
    left = (size - nw) // 2
    right = size - nw - left
    img_p = cv2.copyMakeBorder(img_r, top, bottom, left, right, cv2.BORDER_REFLECT_101)
    return img_p

def background_suppress(img_bgr: np.ndarray) -> np.ndarray:
    """Adaptive background suppression using morphology + dynamic thresholding.

    This is *not* clinical segmentation; it is a robust heuristic to suppress irrelevant
    background/healthy-foot area while keeping ulcer region and nearby context.
    """
    img = img_bgr.copy()
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # Adaptive threshold to find foreground regions
    thr = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                               cv2.THRESH_BINARY_INV, 41, 5)
    # Morphology to remove small speckles and fill gaps
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))
    mask = cv2.morphologyEx(thr, cv2.MORPH_OPEN, k, iterations=1)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k, iterations=2)
    # Keep largest connected component
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    if n > 1:
        largest = 1 + np.argmax(stats[1:, cv2.CC_STAT_AREA])
        mask = (labels == largest).astype(np.uint8) * 255
    # Feather mask
    mask_f = cv2.GaussianBlur(mask, (0, 0), 3)
    mask_f = (mask_f / 255.0)[..., None]
    out = (img * mask_f + (1 - mask_f) * 0).astype(np.uint8)
    return out

def multi_scale_texture_enhance(img_bgr: np.ndarray, sigmas=(0.5, 1.0, 2.0), weights=None) -> np.ndarray:
    """Multi-scale texture enhancement (Difference-of-Gaussians like)."""
    if weights is None:
        weights = np.ones(len(sigmas), dtype=np.float32) / max(1, len(sigmas))
    weights = np.asarray(weights, dtype=np.float32)
    weights = weights / (weights.sum() + 1e-8)
    img = img_bgr.astype(np.float32) / 255.0
    blurred = [cv2.GaussianBlur(img, (0, 0), s) for s in sigmas]
    # Enhance by amplifying high-frequency components per scale
    enhanced = np.zeros_like(img)
    for w, b in zip(weights, blurred):
        enhanced += w * (img - b)
    out = np.clip(img + enhanced, 0, 1)
    return (out * 255.0).astype(np.uint8)

def build_reference_hist(images_bgr: list[np.ndarray], bins: int = 256) -> np.ndarray:
    """Build reference RGB histogram (per-channel) from a subset."""
    ref = []
    for c in range(3):
        h = np.zeros((bins,), dtype=np.float64)
        for im in images_bgr:
            hc, _ = np.histogram(im[..., c].ravel(), bins=bins, range=(0, 255), density=False)
            h += hc
        h = h / (h.sum() + 1e-12)
        ref.append(h)
    return np.stack(ref, axis=0)

def histogram_match(img_bgr: np.ndarray, ref_hist: np.ndarray) -> np.ndarray:
    """Histogram specification to a canonical reference histogram (per channel)."""
    out = img_bgr.copy()
    for c in range(3):
        src = out[..., c].ravel()
        src_hist, bins = np.histogram(src, 256, (0, 255), density=True)
        src_cdf = np.cumsum(src_hist)
        src_cdf = src_cdf / (src_cdf[-1] + 1e-12)

        ref_cdf = np.cumsum(ref_hist[c])
        ref_cdf = ref_cdf / (ref_cdf[-1] + 1e-12)

        # Build mapping: for each src level, find closest ref level
        mapping = np.interp(src_cdf, ref_cdf, np.arange(256))
        matched = mapping[src.astype(np.uint8)].reshape(out[..., c].shape)
        out[..., c] = np.clip(matched, 0, 255).astype(np.uint8)
    return out

def elastic_deform(img_bgr: np.ndarray, alpha: float = 18.0, sigma: float = 5.0, seed: int | None = None) -> np.ndarray:
    """Context-preserving elastic deformation via random smooth displacement fields."""
    rng = np.random.default_rng(seed)
    h, w = img_bgr.shape[:2]
    dx = rng.normal(0, 1, (h, w)).astype(np.float32)
    dy = rng.normal(0, 1, (h, w)).astype(np.float32)
    dx = cv2.GaussianBlur(dx, (0, 0), sigma) * alpha
    dy = cv2.GaussianBlur(dy, (0, 0), sigma) * alpha

    x, y = np.meshgrid(np.arange(w), np.arange(h))
    map_x = (x + dx).astype(np.float32)
    map_y = (y + dy).astype(np.float32)
    return cv2.remap(img_bgr, map_x, map_y, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT_101)
