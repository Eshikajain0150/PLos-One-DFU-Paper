from __future__ import annotations
import torch
import torch.nn.functional as F
from .schedule import DiffusionSchedule

@torch.no_grad()
def q_sample(schedule: DiffusionSchedule, x0: torch.Tensor, t: torch.Tensor, noise: torch.Tensor) -> torch.Tensor:
    # x_t = sqrt(alpha_bar)*x0 + sqrt(1-alpha_bar)*noise
    sqrt_ab = schedule.sqrt_alphas_cumprod[t].view(-1,1,1,1)
    sqrt_omb = schedule.sqrt_one_minus_alphas_cumprod[t].view(-1,1,1,1)
    return sqrt_ab * x0 + sqrt_omb * noise

def p_losses(
    model,
    schedule: DiffusionSchedule,
    x_cond: torch.Tensor,
    y0: torch.Tensor,
    t: torch.Tensor,
    tokens: torch.Tensor | None,
    loss_type: str = "l2",
):
    noise = torch.randn_like(y0)
    y_t = q_sample(schedule, y0, t, noise)
    pred_noise = model(y_t, x_cond, t, tokens)
    if loss_type == "l1":
        return F.l1_loss(pred_noise, noise)
    return F.mse_loss(pred_noise, noise)

@torch.no_grad()
def p_sample(model, schedule: DiffusionSchedule, x_cond: torch.Tensor, tokens: torch.Tensor | None,
             y_t: torch.Tensor, t: int):
    betas_t = schedule.betas[t]
    sqrt_one_minus_ab = schedule.sqrt_one_minus_alphas_cumprod[t]
    sqrt_recip_alpha = torch.sqrt(1.0 / schedule.alphas[t])
    t_batch = torch.full((y_t.shape[0],), t, device=y_t.device, dtype=torch.long)

    pred_noise = model(y_t, x_cond, t_batch, tokens)
    # mean of posterior
    model_mean = sqrt_recip_alpha * (y_t - betas_t * pred_noise / sqrt_one_minus_ab)
    if t == 0:
        return model_mean
    var = schedule.posterior_variance[t]
    noise = torch.randn_like(y_t)
    return model_mean + torch.sqrt(var) * noise

@torch.no_grad()
def sample(model, schedule: DiffusionSchedule, x_cond: torch.Tensor, tokens: torch.Tensor | None, steps: int | None = None):
    T = schedule.timesteps if steps is None else steps
    y_t = torch.randn_like(x_cond)
    for t in reversed(range(T)):
        y_t = p_sample(model, schedule, x_cond, tokens, y_t, t)
    return y_t
