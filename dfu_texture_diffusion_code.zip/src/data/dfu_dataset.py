from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple
import csv
import numpy as np
import cv2
import torch
from torch.utils.data import Dataset
import albumentations as A

from .preprocess import resize_pad, background_suppress, multi_scale_texture_enhance, histogram_match, elastic_deform

@dataclass
class SplitRecord:
    path: str
    stage: int
    score: float

def load_split_csv(csv_path: str) -> list[SplitRecord]:
    out = []
    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            out.append(SplitRecord(path=r["path"], stage=int(r["stage"]), score=float(r["score"])))
    return out

class DFUPairedPseudoProgression(Dataset):
    """Builds pseudo-progression pairs by sampling a target image from a later stage.

    Input x: image from stage s
    Target y: image from stage s+1 (or higher) chosen randomly.

    NOTE: This follows the manuscript's pseudo-progression paradigm (no true longitudinal pairs).
    """
    def __init__(
        self,
        data_root: str,
        split_csv: str,
        reference_hist_npy: str,
        image_size: int = 256,
        num_stages: int = 4,
        augment: bool = True,
        seed: int = 2026,
    ) -> None:
        self.data_root = Path(data_root)
        self.recs = load_split_csv(split_csv)
        self.image_size = image_size
        self.num_stages = num_stages
        self.seed = seed
        self.rng = np.random.default_rng(seed)
        self.ref_hist = np.load(reference_hist_npy)

        # stage -> indices
        self.by_stage = {s: [] for s in range(num_stages)}
        for i, r in enumerate(self.recs):
            self.by_stage[r.stage].append(i)

        self.aug = A.Compose([
            A.HorizontalFlip(p=0.5),
            A.RandomBrightnessContrast(p=0.25),
            A.ColorJitter(p=0.2),
        ]) if augment else None

    def __len__(self) -> int:
        return len(self.recs)

    def _read(self, rel_path: str) -> np.ndarray:
        p = self.data_root / rel_path
        img = cv2.imread(str(p), cv2.IMREAD_COLOR)
        if img is None:
            raise FileNotFoundError(f"Could not read image: {p}")
        return img

    def _pipeline(self, img: np.ndarray, do_elastic: bool) -> np.ndarray:
        img = resize_pad(img, self.image_size)
        img = background_suppress(img)
        img = multi_scale_texture_enhance(img)
        img = histogram_match(img, self.ref_hist)
        if do_elastic:
            img = elastic_deform(img, seed=int(self.rng.integers(0, 1_000_000)))
        return img

    def __getitem__(self, idx: int):
        rec = self.recs[idx]
        x = self._read(rec.path)
        # choose a later stage for target
        later = min(rec.stage + 1, self.num_stages - 1)
        cand = self.by_stage[later] if len(self.by_stage[later]) > 0 else list(range(len(self.recs)))
        j = int(self.rng.choice(cand))
        y = self._read(self.recs[j].path)

        # preprocessing & augmentation
        x = self._pipeline(x, do_elastic=True)
        y = self._pipeline(y, do_elastic=True)
        if self.aug is not None:
            x = self.aug(image=x)["image"]
            y = self.aug(image=y)["image"]

        # BGR -> RGB, to tensor [-1, 1]
        x = cv2.cvtColor(x, cv2.COLOR_BGR2RGB)
        y = cv2.cvtColor(y, cv2.COLOR_BGR2RGB)
        x = torch.from_numpy(x).permute(2,0,1).float() / 127.5 - 1.0
        y = torch.from_numpy(y).permute(2,0,1).float() / 127.5 - 1.0
        stage = torch.tensor(rec.stage, dtype=torch.long)
        return {"x": x, "y": y, "stage": stage, "x_path": rec.path, "y_path": self.recs[j].path}
