from __future__ import annotations
from pathlib import Path
from typing import List, Tuple

IMG_EXTS = {".jpg",".jpeg",".png",".webp",".bmp",".tif",".tiff"}

def discover_images(data_root: str) -> List[str]:
    root = Path(data_root)
    paths = [str(p) for p in root.rglob("*") if p.suffix.lower() in IMG_EXTS]
    paths.sort()
    return paths
