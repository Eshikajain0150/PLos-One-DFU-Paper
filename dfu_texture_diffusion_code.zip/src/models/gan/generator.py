from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F

class UNetGenerator(nn.Module):
    def __init__(self, in_ch=3, base=64, out_ch=3):
        super().__init__()
        self.d1 = nn.Sequential(nn.Conv2d(in_ch, base, 4,2,1), nn.LeakyReLU(0.2, True))
        self.d2 = nn.Sequential(nn.Conv2d(base, base*2, 4,2,1), nn.BatchNorm2d(base*2), nn.LeakyReLU(0.2, True))
        self.d3 = nn.Sequential(nn.Conv2d(base*2, base*4, 4,2,1), nn.BatchNorm2d(base*4), nn.LeakyReLU(0.2, True))
        self.d4 = nn.Sequential(nn.Conv2d(base*4, base*8, 4,2,1), nn.BatchNorm2d(base*8), nn.LeakyReLU(0.2, True))
        self.u3 = nn.Sequential(nn.ConvTranspose2d(base*8, base*4, 4,2,1), nn.BatchNorm2d(base*4), nn.ReLU(True))
        self.u2 = nn.Sequential(nn.ConvTranspose2d(base*8, base*2, 4,2,1), nn.BatchNorm2d(base*2), nn.ReLU(True))
        self.u1 = nn.Sequential(nn.ConvTranspose2d(base*4, base, 4,2,1), nn.BatchNorm2d(base), nn.ReLU(True))
        self.out = nn.Sequential(nn.ConvTranspose2d(base*2, out_ch, 4,2,1), nn.Tanh())

    def forward(self, x):
        s1 = self.d1(x)
        s2 = self.d2(s1)
        s3 = self.d3(s2)
        h = self.d4(s3)
        h = self.u3(h)
        h = torch.cat([h, s3], dim=1)
        h = self.u2(h)
        h = torch.cat([h, s2], dim=1)
        h = self.u1(h)
        h = torch.cat([h, s1], dim=1)
        return self.out(h)
