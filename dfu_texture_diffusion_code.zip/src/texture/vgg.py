from __future__ import annotations
from dataclasses import dataclass
from typing import List
import torch
import torch.nn as nn
from torchvision.models import vgg19, VGG19_Weights

@dataclass
class VGGFeatureConfig:
    # indices in vgg.features to capture (after relu typically)
    layers: List[int] = (2, 7, 16, 25)  # conv1_2, conv2_2, conv3_4, conv4_4 approx

class VGG19Features(nn.Module):
    def __init__(self, cfg: VGGFeatureConfig = VGGFeatureConfig()):
        super().__init__()
        self.cfg = cfg
        self.vgg = vgg19(weights=VGG19_Weights.IMAGENET1K_V1).features.eval()
        for p in self.vgg.parameters():
            p.requires_grad = False

    @torch.no_grad()
    def forward(self, x: torch.Tensor) -> List[torch.Tensor]:
        feats = []
        h = x
        for i, layer in enumerate(self.vgg):
            h = layer(h)
            if i in self.cfg.layers:
                feats.append(h)
        return feats
