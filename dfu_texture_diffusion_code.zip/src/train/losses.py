from __future__ import annotations
import torch
import torch.nn.functional as F
from torchvision.models import vgg19, VGG19_Weights

class PerceptualLoss(torch.nn.Module):
    def __init__(self, layers=(2,7,16,25)):
        super().__init__()
        self.layers = set(layers)
        self.vgg = vgg19(weights=VGG19_Weights.IMAGENET1K_V1).features.eval()
        for p in self.vgg.parameters():
            p.requires_grad = False

    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        # pred/target: [-1,1] -> [0,1]
        p = (pred + 1.0)/2.0
        t = (target + 1.0)/2.0
        loss = 0.0
        hp, ht = p, t
        for i, layer in enumerate(self.vgg):
            hp = layer(hp)
            ht = layer(ht)
            if i in self.layers:
                loss = loss + F.l1_loss(hp, ht)
        return loss
