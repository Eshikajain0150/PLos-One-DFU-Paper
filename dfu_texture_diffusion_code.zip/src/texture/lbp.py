from __future__ import annotations
import numpy as np
from skimage.feature import local_binary_pattern

def lbp_map(gray: np.ndarray, P: int = 8, R: int = 1) -> np.ndarray:
    """Compute LBP map (uniform patterns)."""
    lbp = local_binary_pattern(gray, P=P, R=R, method="uniform").astype(np.float32)
    # Normalize to [0,1]
    lbp = lbp / (lbp.max() + 1e-6)
    return lbp

def lbp_hist(lbp: np.ndarray, bins: int = 59) -> np.ndarray:
    # Uniform LBP with P=8,R=1 has 59 possible patterns
    h, _ = np.histogram(lbp.ravel(), bins=bins, range=(0,1), density=True)
    return h.astype(np.float32)
