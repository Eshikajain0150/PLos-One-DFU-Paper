from __future__ import annotations
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange

def sinusoidal_time_embedding(timesteps: torch.Tensor, dim: int) -> torch.Tensor:
    device = timesteps.device
    half = dim // 2
    freqs = torch.exp(-math.log(10000) * torch.arange(0, half, device=device).float() / half)
    args = timesteps.float()[:, None] * freqs[None]
    emb = torch.cat([torch.sin(args), torch.cos(args)], dim=-1)
    if dim % 2 == 1:
        emb = F.pad(emb, (0,1))
    return emb

class ResBlock(nn.Module):
    def __init__(self, in_ch, out_ch, time_dim):
        super().__init__()
        self.norm1 = nn.GroupNorm(8, in_ch)
        self.conv1 = nn.Conv2d(in_ch, out_ch, 3, padding=1)
        self.norm2 = nn.GroupNorm(8, out_ch)
        self.conv2 = nn.Conv2d(out_ch, out_ch, 3, padding=1)
        self.time_mlp = nn.Sequential(nn.SiLU(), nn.Linear(time_dim, out_ch))
        self.skip = nn.Conv2d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity()

    def forward(self, x, t_emb):
        h = self.conv1(F.silu(self.norm1(x)))
        h = h + self.time_mlp(t_emb)[:, :, None, None]
        h = self.conv2(F.silu(self.norm2(h)))
        return h + self.skip(x)

class CrossAttention2D(nn.Module):
    """Cross-attention over spatial features (queries) attending to texture tokens (keys/values)."""
    def __init__(self, channels: int, token_dim: int, heads: int = 4):
        super().__init__()
        self.heads = heads
        self.scale = (channels // heads) ** -0.5
        self.to_q = nn.Linear(channels, channels, bias=False)
        self.to_k = nn.Linear(token_dim, channels, bias=False)
        self.to_v = nn.Linear(token_dim, channels, bias=False)
        self.proj = nn.Linear(channels, channels)

    def forward(self, x: torch.Tensor, tokens: torch.Tensor) -> torch.Tensor:
        # x: (B,C,H,W), tokens: (B,N,token_dim)
        B, C, H, W = x.shape
        q = rearrange(x, "b c h w -> b (h w) c")
        q = self.to_q(q)

        k = self.to_k(tokens)
        v = self.to_v(tokens)

        # split heads
        q = rearrange(q, "b n (h d) -> b h n d", h=self.heads)
        k = rearrange(k, "b n (h d) -> b h n d", h=self.heads)
        v = rearrange(v, "b n (h d) -> b h n d", h=self.heads)

        attn = torch.softmax(torch.matmul(q, k.transpose(-2, -1)) * self.scale, dim=-1)
        out = torch.matmul(attn, v)
        out = rearrange(out, "b h n d -> b n (h d)")
        out = self.proj(out)
        out = rearrange(out, "b (h w) c -> b c h w", h=H, w=W)
        return x + out

class Down(nn.Module):
    def __init__(self, in_ch, out_ch, time_dim):
        super().__init__()
        self.rb = ResBlock(in_ch, out_ch, time_dim)
        self.down = nn.Conv2d(out_ch, out_ch, 4, stride=2, padding=1)

    def forward(self, x, t):
        x = self.rb(x, t)
        skip = x
        x = self.down(x)
        return x, skip

class Up(nn.Module):
    def __init__(self, in_ch, out_ch, time_dim):
        super().__init__()
        self.up = nn.ConvTranspose2d(in_ch, out_ch, 4, stride=2, padding=1)
        self.rb = ResBlock(out_ch*2, out_ch, time_dim)

    def forward(self, x, skip, t):
        x = self.up(x)
        x = torch.cat([x, skip], dim=1)
        x = self.rb(x, t)
        return x

class UNetConditionalCA(nn.Module):
    def __init__(self, img_ch=3, base=64, time_dim=256, token_dim=256, use_cross_attention: bool = True):
        super().__init__()
        self.time_dim = time_dim
        self.use_cross_attention = use_cross_attention

        self.time_mlp = nn.Sequential(
            nn.Linear(time_dim, time_dim*4),
            nn.SiLU(),
            nn.Linear(time_dim*4, time_dim),
        )

        self.in_conv = nn.Conv2d(img_ch*2, base, 3, padding=1)  # concat noisy y_t and conditioning x
        self.down1 = Down(base, base*2, time_dim)
        self.down2 = Down(base*2, base*4, time_dim)
        self.down3 = Down(base*4, base*8, time_dim)

        self.mid = ResBlock(base*8, base*8, time_dim)
        self.ca_mid = CrossAttention2D(base*8, token_dim, heads=8)

        self.up3 = Up(base*8, base*4, time_dim)
        self.up2 = Up(base*4, base*2, time_dim)
        self.up1 = Up(base*2, base, time_dim)

        self.ca1 = CrossAttention2D(base*4, token_dim, heads=4)
        self.ca2 = CrossAttention2D(base*2, token_dim, heads=4)
        self.ca3 = CrossAttention2D(base, token_dim, heads=4)

        self.out = nn.Sequential(
            nn.GroupNorm(8, base),
            nn.SiLU(),
            nn.Conv2d(base, img_ch, 3, padding=1),
        )

    def forward(self, y_t: torch.Tensor, x_cond: torch.Tensor, t: torch.Tensor, tokens: torch.Tensor | None):
        # time embedding
        t_emb = sinusoidal_time_embedding(t, self.time_dim)
        t_emb = self.time_mlp(t_emb)

        h = self.in_conv(torch.cat([y_t, x_cond], dim=1))
        h, s1 = self.down1(h, t_emb)
        h, s2 = self.down2(h, t_emb)
        h, s3 = self.down3(h, t_emb)

        h = self.mid(h, t_emb)
        if self.use_cross_attention and (tokens is not None):
            h = self.ca_mid(h, tokens)

        h = self.up3(h, s3, t_emb)
        if self.use_cross_attention and (tokens is not None):
            h = self.ca1(h, tokens)

        h = self.up2(h, s2, t_emb)
        if self.use_cross_attention and (tokens is not None):
            h = self.ca2(h, tokens)

        h = self.up1(h, s1, t_emb)
        if self.use_cross_attention and (tokens is not None):
            h = self.ca3(h, tokens)

        return self.out(h)  # predicted noise
