from __future__ import annotations
import torch
import torch.nn as nn

class PatchDiscriminator(nn.Module):
    def __init__(self, in_ch: int = 6, base: int = 64):
        super().__init__()
        def block(ic, oc, norm=True):
            layers = [nn.Conv2d(ic, oc, 4, stride=2, padding=1)]
            if norm:
                layers.append(nn.BatchNorm2d(oc))
            layers.append(nn.LeakyReLU(0.2, inplace=True))
            return layers
        self.net = nn.Sequential(
            *block(in_ch, base, norm=False),
            *block(base, base*2),
            *block(base*2, base*4),
            *block(base*4, base*8),
            nn.Conv2d(base*8, 1, 3, padding=1)
        )
    def forward(self, x):
        return self.net(x)
