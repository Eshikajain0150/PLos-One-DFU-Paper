from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange
from .vgg import VGG19Features
from .lbp import lbp_map

class TextureEncoder(nn.Module):
    """Hybrid texture encoding: LBP map + VGG-19 perceptual features.

    Output: texture tokens used for cross-attention (B, N, C)
    """
    def __init__(self, token_dim: int = 256, vgg_in_ch: int = 3):
        super().__init__()
        self.vgg = VGG19Features()
        # project concatenated multi-scale VGG features to token_dim
        # we pool each feature map to 32x32 then concat along channel.
        self.proj = nn.Sequential(
            nn.Conv2d(64 + 128 + 256 + 512 + 1, token_dim, kernel_size=1),
            nn.GroupNorm(8, token_dim),
            nn.SiLU(),
            nn.Conv2d(token_dim, token_dim, kernel_size=1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [-1,1], RGB, (B,3,H,W)
        B, _, H, W = x.shape
        x01 = (x + 1.0) / 2.0

        # LBP on grayscale (done in torch using cpu-friendly op via approximation: compute on CPU with loops is slow).
        # Here we approximate by computing LBP on downsampled grayscale via a tiny conv-based texture map.
        # For faithful LBP-based evaluation, see metrics/tcs.py which uses skimage on CPU.
        gray = 0.2989*x01[:,0:1] + 0.5870*x01[:,1:2] + 0.1140*x01[:,2:3]
        # local contrast approximation as a proxy for LBP conditioning (fast)
        lap = torch.abs(F.conv2d(gray, weight=torch.tensor([[[[0,-1,0],[-1,4,-1],[0,-1,0]]]], device=gray.device, dtype=gray.dtype), padding=1))
        lap = F.avg_pool2d(lap, kernel_size=2, stride=2)
        lap = F.interpolate(lap, size=(32,32), mode="bilinear", align_corners=False)

        feats = self.vgg(x01)
        pooled = []
        for f in feats:
            pooled.append(F.interpolate(f, size=(32,32), mode="bilinear", align_corners=False))
        cat = torch.cat(pooled + [lap], dim=1)
        z = self.proj(cat)  # (B, token_dim, 32, 32)
        tokens = rearrange(z, "b c h w -> b (h w) c")
        tokens = F.layer_norm(tokens, (tokens.shape[-1],))
        return tokens
