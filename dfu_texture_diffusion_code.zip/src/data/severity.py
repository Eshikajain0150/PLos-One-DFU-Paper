from __future__ import annotations
import numpy as np
import cv2

def ulcer_mask_heuristic(img_bgr: np.ndarray) -> np.ndarray:
    """Heuristic ulcer region mask (HSV + morphology)."""
    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    # ulcer-ish colors: reddish/brownish/yellowish; use broad hue range + saturation/value constraints
    # (heuristic only; adjust if needed)
    mask1 = cv2.inRange(hsv, (0, 40, 40), (25, 255, 255))   # red/orange
    mask2 = cv2.inRange(hsv, (160, 40, 40), (180, 255, 255)) # red wrap
    mask3 = cv2.inRange(hsv, (25, 30, 30), (45, 255, 255))  # yellow/slough
    mask = cv2.bitwise_or(mask1, mask2)
    mask = cv2.bitwise_or(mask, mask3)

    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k, iterations=1)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k, iterations=2)
    return (mask > 0).astype(np.uint8)

def tissue_ratios(img_bgr: np.ndarray, ulcer_mask: np.ndarray) -> dict:
    """Approximate granulation / slough / necrosis ratios using color thresholds inside ulcer mask."""
    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    m = ulcer_mask.astype(bool)
    if m.sum() < 10:
        return {"granulation":0.0,"slough":0.0,"necrosis":0.0}
    # granulation: reddish/pink
    gran = (cv2.inRange(hsv, (0, 60, 60), (20, 255, 255)) > 0) | (cv2.inRange(hsv, (160, 60, 60), (180, 255, 255)) > 0)
    # slough: yellow/greenish
    slough = (cv2.inRange(hsv, (20, 40, 60), (50, 255, 255)) > 0)
    # necrosis: dark/black/brown (low V)
    nec = (cv2.inRange(hsv, (0, 0, 0), (180, 255, 55)) > 0)

    gran_r = float((gran & m).sum()) / float(m.sum())
    slough_r = float((slough & m).sum()) / float(m.sum())
    nec_r = float((nec & m).sum()) / float(m.sum())
    return {"granulation":gran_r,"slough":slough_r,"necrosis":nec_r}

def severity_score(img_bgr: np.ndarray) -> float:
    """Severity proxy score used to create ordinal pseudo-stages.

    Combines:
    - ulcer area ratio (larger ≈ more severe)
    - necrosis ratio (more necrosis ≈ more severe)
    - inverse granulation ratio (less granulation ≈ more severe)
    """
    m = ulcer_mask_heuristic(img_bgr)
    area = float(m.mean())  # fraction of pixels in mask
    ratios = tissue_ratios(img_bgr, m)
    score = 1.8*area + 2.5*ratios["necrosis"] + 1.0*ratios["slough"] + 1.2*(1.0 - ratios["granulation"])
    return float(score)
