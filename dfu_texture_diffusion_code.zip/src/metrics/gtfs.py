from __future__ import annotations
import os
from pathlib import Path
import numpy as np
import cv2

def granulation_mask_proxy(img_rgb: np.ndarray) -> np.ndarray:
    """Proxy granulation mask using HSV thresholds (reddish/pink)."""
    bgr = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR)
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    m1 = cv2.inRange(hsv, (0, 60, 60), (20, 255, 255))
    m2 = cv2.inRange(hsv, (160, 60, 60), (180, 255, 255))
    m = cv2.bitwise_or(m1, m2)
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5,5))
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, k, iterations=1)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, k, iterations=1)
    return (m > 0).astype(np.uint8)

def load_mask_if_exists(image_path: str, masks_dir: str | None) -> np.ndarray | None:
    if masks_dir is None:
        return None
    p = Path(image_path)
    stem = p.stem
    cand = [Path(masks_dir)/f for f in [stem+".png", stem+".jpg", stem+".jpeg"]]
    for c in cand:
        if c.exists():
            m = cv2.imread(str(c), cv2.IMREAD_GRAYSCALE)
            if m is None:
                continue
            return (m > 127).astype(np.uint8)
    return None

def dice(a: np.ndarray, b: np.ndarray) -> float:
    a = a.astype(bool); b = b.astype(bool)
    inter = (a & b).sum()
    denom = a.sum() + b.sum()
    if denom == 0:
        return 1.0
    return float(2.0*inter / denom)

def gtfs(pred_rgb: np.ndarray, ref_rgb: np.ndarray, image_path: str, masks_dir: str | None = None) -> float:
    """GTFS: Dice similarity between granulation masks.

    If `masks_dir` contains expert masks -> uses those.
    Else -> uses proxy masks derived from color heuristics.

    Higher is better.
    """
    ref_mask = load_mask_if_exists(image_path, masks_dir)
    if ref_mask is None:
        ref_mask = granulation_mask_proxy(ref_rgb)
    pred_mask = granulation_mask_proxy(pred_rgb)
    return dice(pred_mask, ref_mask)
